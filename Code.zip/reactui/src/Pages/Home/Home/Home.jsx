import React from 'react';
import Footer from '../Footer/Footer.jsx';
import Header from '../Header/Header.jsx';

import Banner1 from '../Banner1/Banner1';


const Home = () => {

    return (
        <>
        <Header />
           <Banner1 />
           
           <Footer />
          
        </>
    );
};

export default Home;