import React from 'react';
import Banner from '../Banner/Banner';
import Footer from '../Footer/Footer.jsx';
import Header2 from '../Header2/Header2.jsx';
const Adminhome = () => {
    

    return (
        <>
          <Header2 />
           <Banner />           
           <Footer/>
        </>
    );
};

export default Adminhome;