export const FakeService = [
    {
        "id": "001",
        "title": "Complete Dentistry",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type and setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/dentistry.svg"
    },
    {
        "id": "002",
        "title": "Dental Selants",
        "description": "Get our text demo is simply dummy text of the printings and type and setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/selant.svg"
    },
    {
        "id": "003",
        "title": "Dental Dictionary",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/dictionary.svg"
    },
    {
        "id": "004",
        "title": "Dental Implants",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type and setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/implants.svg"
    },
    {
        "id": "005",
        "title": "Oral Surgery",
        "description": "Get our text demo is simply dummy text of the printings and type and setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/oral.svg"
    },
    {
        "id": "006",
        "title": "General Dentistry",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type setting for content",
        "link": "Read More",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Services/general.svg"
    }
]