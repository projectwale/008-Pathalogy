export const FakeFeatures = [
    {
        "id": "001",
        "title": "Easy Appointment",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type setting",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Features/feature1.svg"
    },
    {
        "id": "002",
        "title": "Emergency Service",
        "description": "Get our text demo is simply dummy text of the printings and type for content",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Features/feature2.svg"
    },
    {
        "id": "003",
        "title": "24/7 Service",
        "description": "Lorem Ipsum is simply is very dummy text of the printings and type setting",
        "img": "https://raw.githubusercontent.com/saifulemon/images-for-all-project/main/Donto/Features/feature3.svg"
    }
]


